import requests
import telebot
from bs4 import BeautifulSoup as BS
import os
ip = os.environ['ip']

bot = telebot.TeleBot('1652958415:AAHAQ_3VS56_XBPw2lDbnV_AKLBHybpfy0E')

# ip = '3.127.57.254'
r = requests.get('http://' + ip)
html = BS(r.content, 'html.parser')

h1 = html.select('h1')[0].text.strip()
p = html.select('p')[0].text.strip()

def lambda_handler(event, context):
    bot.send_message(105996029, '*IP address: *' + ip + '\n' + '*Заголовок: *' + h1 + '\n' + '*Текст: *' + p, parse_mode= 'Markdown')
